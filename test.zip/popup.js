/**
 * Databytes Keyhouse — Popup Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  const lockedView = document.getElementById('lockedView');
  const loginsView = document.getElementById('loginsView');
  const generatorView = document.getElementById('generatorView');
  const tabBar = document.getElementById('tabBar');
  const passphraseInput = document.getElementById('passphraseInput');
  const unlockBtn = document.getElementById('unlockBtn');
  const unlockError = document.getElementById('unlockError');
  const lockVaultBtn = document.getElementById('lockVaultBtn');
  const currentOrigin = document.getElementById('currentOrigin');
  const loginList = document.getElementById('loginList');

  // Generator elements
  const generatedPass = document.getElementById('generatedPass');
  const regenBtn = document.getElementById('regenBtn');
  const copyGenBtn = document.getElementById('copyGenBtn');
  const lenRange = document.getElementById('lenRange');
  const lenDisplay = document.getElementById('lenDisplay');

  let activeTabUrl = '';

  // Get active tab info
  if (chrome && chrome.tabs && chrome.tabs.query) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url) {
        activeTabUrl = tabs[0].url;
        try {
          const u = new URL(activeTabUrl);
          currentOrigin.textContent = u.hostname;
        } catch (e) {
          currentOrigin.textContent = activeTabUrl;
        }
      }
      checkStatus();
    });
  } else {
    checkStatus();
  }

  function checkStatus() {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
      if (response && response.isUnlocked) {
        showUnlockedView();
      } else {
        showLockedView();
      }
    });
  }

  function showLockedView() {
    lockedView.classList.remove('hidden');
    loginsView.classList.add('hidden');
    generatorView.classList.add('hidden');
    tabBar.classList.add('hidden');
    lockVaultBtn.classList.add('hidden');
  }

  function showUnlockedView() {
    lockedView.classList.add('hidden');
    loginsView.classList.remove('hidden');
    generatorView.classList.add('hidden');
    tabBar.classList.remove('hidden');
    lockVaultBtn.classList.remove('hidden');

    loadMatchingLogins();
  }

  function loadMatchingLogins() {
    chrome.runtime.sendMessage({ type: 'GET_MATCHING_LOGINS', url: activeTabUrl }, (res) => {
      loginList.innerHTML = '';

      if (!res || !res.logins || res.logins.length === 0) {
        loginList.innerHTML = `
          <div style="text-align: center; color: #71717a; padding: 24px 0;">
            <p>No saved logins found for this domain.</p>
            <p style="font-size: 11px; margin-top: 6px;">Add website logins in the Keyhouse Web Vault to autofill here.</p>
          </div>
        `;
        return;
      }

      res.logins.forEach((login) => {
        const card = document.createElement('div');
        card.className = 'credential-card';
        card.innerHTML = `
          <div class="credential-title">${escapeHtml(login.name || 'Login')}</div>
          <div class="credential-meta">${escapeHtml(login.username || 'No username')}</div>
          <div class="btn-group">
            <button class="btn-secondary copy-user-btn">Copy User</button>
            <button class="btn-secondary copy-pass-btn">Copy Pass</button>
            <button class="btn-primary fill-btn" style="padding: 5px 8px; font-size: 11px; width: auto; flex: 1.2;">Autofill</button>
          </div>
        `;

        card.querySelector('.copy-user-btn').addEventListener('click', () => {
          navigator.clipboard.writeText(login.username);
          flashButton(card.querySelector('.copy-user-btn'), 'Copied!');
        });

        card.querySelector('.copy-pass-btn').addEventListener('click', () => {
          navigator.clipboard.writeText(login.password);
          flashButton(card.querySelector('.copy-pass-btn'), 'Copied!');
        });

        card.querySelector('.fill-btn').addEventListener('click', () => {
          // Execute autofill in active tab
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].id) {
              chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: (u, p) => {
                  const passInput = document.querySelector('input[type="password"]');
                  if (passInput) {
                    passInput.value = p;
                    passInput.dispatchEvent(new Event('input', { bubbles: true }));
                    passInput.dispatchEvent(new Event('change', { bubbles: true }));

                    const form = passInput.closest('form') || document;
                    const userInput = form.querySelector('input[type="text"], input[type="email"], input[autocomplete*="username"]');
                    if (userInput && u) {
                      userInput.value = u;
                      userInput.dispatchEvent(new Event('input', { bubbles: true }));
                      userInput.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                  }
                },
                args: [login.username, login.password]
              });
              flashButton(card.querySelector('.fill-btn'), 'Filled!');
            }
          });
        });

        loginList.appendChild(card);
      });
    });
  }

  function flashButton(btn, text) {
    const orig = btn.textContent;
    btn.textContent = text;
    setTimeout(() => {
      btn.textContent = orig;
    }, 1200);
  }

  // Handle Unlock
  unlockBtn.addEventListener('click', () => {
    const pass = passphraseInput.value.trim();
    if (!pass) return;

    unlockError.classList.add('hidden');
    unlockBtn.textContent = 'Unlocking...';

    // If local envelope cached in storage, unlock directly; otherwise fetch from server
    chrome.storage.local.get(['encryptedEnvelope', 'userEmail'], (data) => {
      if (data && data.encryptedEnvelope) {
        chrome.runtime.sendMessage({
          type: 'UNLOCK_WITH_PASSPHRASE',
          passphrase: pass,
          envelope: data.encryptedEnvelope,
          userEmail: data.userEmail
        }, (res) => {
          unlockBtn.textContent = 'Unlock Vault';
          if (res && res.success) {
            passphraseInput.value = '';
            showUnlockedView();
          } else {
            unlockError.textContent = res.error || 'Failed to unlock';
            unlockError.classList.remove('hidden');
          }
        });
      } else {
        // Vault is unlocked via syncing with the web client
        unlockBtn.textContent = 'Unlock Vault';
        unlockError.textContent = 'Please sign in and sync vault from the Keyhouse Web App first.';
        unlockError.classList.remove('hidden');
      }
    });
  });

  // Handle Lock
  lockVaultBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'LOCK_VAULT' }, () => {
      showLockedView();
    });
  });

  // Tab switching
  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      const target = btn.getAttribute('data-tab');
      if (target === 'tabLogins') {
        loginsView.classList.remove('hidden');
        generatorView.classList.add('hidden');
      } else {
        loginsView.classList.add('hidden');
        generatorView.classList.remove('hidden');
        renderPassword();
      }
    });
  });

  // Password Generator
  function generateQuickPassword(len) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*()-_=+';
    let res = '';
    const arr = new Uint32Array(len);
    crypto.getRandomValues(arr);
    for (let i = 0; i < len; i++) {
      res += chars[arr[i] % chars.length];
    }
    return res;
  }

  function renderPassword() {
    const len = parseInt(lenRange.value, 10);
    lenDisplay.textContent = len;
    generatedPass.textContent = generateQuickPassword(len);
  }

  lenRange.addEventListener('input', renderPassword);
  regenBtn.addEventListener('click', renderPassword);

  copyGenBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(generatedPass.textContent);
    flashButton(copyGenBtn, 'Copied to Clipboard!');
  });

  function escapeHtml(str) {
    return (str || '').replace(/[&<>'"]/g, (tag) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }
});
