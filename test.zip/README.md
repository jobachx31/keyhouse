# Databytes Keyhouse — Chrome Extension (Manifest V3)

This is the official Chrome extension companion for **Databytes Keyhouse**, a zero-knowledge password manager.

## Features
- **Zero-Knowledge Architecture**: Encryption and decryption happen locally in the extension context.
- **Strict Origin-Matched Autofill**: Automatically identifies login and password input fields and matches against exact hostnames.
- **In-Memory Key Storage**: Decrypted master keys and records are stored strictly in volatile memory and automatically wiped upon lock or after 15 minutes of inactivity.
- **Quick Generator**: Create cryptographically secure passwords on the fly and copy them instantly.

## Installation in Google Chrome, Brave, or Edge

1. **Download and Extract**:
   - Download the `databytes-keyhouse-extension.zip` file directly from the Keyhouse Web Vault (under Settings > Chrome Extension or the top bar).
   - Unzip the contents into a local folder (e.g. `databytes-keyhouse-extension/`).

2. **Open Extensions Page**:
   - In Google Chrome or Brave, navigate to: `chrome://extensions`
   - In Microsoft Edge, navigate to: `edge://extensions`

3. **Enable Developer Mode**:
   - Toggle the **Developer mode** switch in the upper-right corner.

4. **Load Unpacked**:
   - Click the **Load unpacked** button in the top toolbar.
   - Select the unzipped `databytes-keyhouse-extension/` directory containing `manifest.json`.

5. **Pin and Use**:
   - Click the puzzle icon in Chrome's toolbar and pin **Databytes Keyhouse**.
   - Unlock your vault with your client-side passphrase and enjoy seamless autofill!
