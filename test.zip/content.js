/**
 * Databytes Keyhouse — Content Script for Secure Autofill
 *
 * Scans page DOM for login and password fields, requests origin-verified
 * credentials from the trusted background worker, and provides seamless autofill.
 */

(function () {
  let matchingLogins = [];
  let isUnlocked = false;

  // Request matching credentials for this webpage's origin
  function checkAndAttachAutofill() {
    try {
      chrome.runtime.sendMessage(
        { type: 'GET_MATCHING_LOGINS', url: window.location.href },
        (response) => {
          if (chrome.runtime.lastError || !response) return;

          isUnlocked = response.isUnlocked;
          matchingLogins = response.logins || [];

          if (matchingLogins.length > 0) {
            injectAutofillBadges();
          }
        }
      );
    } catch (e) {
      // Chrome extension context may not be ready
    }
  }

  // Find password inputs and inject discreet Keyhouse badge
  function injectAutofillBadges() {
    const passwordInputs = document.querySelectorAll('input[type="password"]:not([data-keyhouse-injected])');

    passwordInputs.forEach((input) => {
      input.setAttribute('data-keyhouse-injected', 'true');

      // Create container wrapper if not positioned
      const parent = input.parentElement;
      if (!parent) return;

      const container = document.createElement('div');
      container.className = 'keyhouse-input-badge-wrapper';
      container.style.cssText = `
        position: relative;
        display: inline-block;
        width: 100%;
      `;

      // Insert wrapper around input
      parent.insertBefore(container, input);
      container.appendChild(input);

      // Create Keyhouse badge icon button inside the input field
      const badge = document.createElement('button');
      badge.type = 'button';
      badge.setAttribute('aria-label', 'Databytes Keyhouse Autofill');
      badge.title = 'Databytes Keyhouse: Autofill saved login';
      badge.style.cssText = `
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        background: #18181b;
        border: 1px solid rgba(245, 158, 11, 0.4);
        border-radius: 4px;
        width: 22px;
        height: 22px;
        padding: 2px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        transition: all 0.15s ease;
      `;

      badge.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="7.5" cy="15.5" r="5.5"></circle>
          <path d="m21 2-9.6 9.6"></path>
          <path d="m15.5 7.5 3 3L22 7l-3-3"></path>
        </svg>
      `;

      badge.addEventListener('mouseenter', () => {
        badge.style.borderColor = '#f59e0b';
        badge.style.background = '#27272a';
      });
      badge.addEventListener('mouseleave', () => {
        badge.style.borderColor = 'rgba(245, 158, 11, 0.4)';
        badge.style.background = '#18181b';
      });

      // Show dropdown on click
      badge.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        showAutofillMenu(container, input);
      });

      container.appendChild(badge);
    });
  }

  // Display credential selection dropdown
  function showAutofillMenu(container, passwordInput) {
    // Remove existing menus
    const existing = document.querySelector('.keyhouse-autofill-dropdown');
    if (existing) existing.remove();

    if (matchingLogins.length === 0) return;

    const dropdown = document.createElement('div');
    dropdown.className = 'keyhouse-autofill-dropdown';
    dropdown.style.cssText = `
      position: absolute;
      top: 100%;
      right: 0;
      margin-top: 6px;
      background: #121214;
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 8px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(245, 158, 11, 0.2);
      padding: 6px;
      min-width: 240px;
      z-index: 10000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color: #f4f4f5;
    `;

    const header = document.createElement('div');
    header.style.cssText = `
      padding: 6px 8px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: #f59e0b;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      margin-bottom: 4px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    `;
    header.innerHTML = `<span>Databytes Keyhouse</span><span style="font-size: 10px; color: #71717a;">${matchingLogins.length} login${matchingLogins.length > 1 ? 's' : ''}</span>`;
    dropdown.appendChild(header);

    matchingLogins.forEach((login) => {
      const itemBtn = document.createElement('button');
      itemBtn.type = 'button';
      itemBtn.style.cssText = `
        display: block;
        width: 100%;
        text-align: left;
        padding: 8px 10px;
        background: transparent;
        border: none;
        border-radius: 6px;
        color: #f4f4f5;
        cursor: pointer;
        transition: background 0.1s;
      `;

      itemBtn.innerHTML = `
        <div style="font-weight: 500; font-size: 13px; color: #fff;">${escapeHtml(login.name || 'Login')}</div>
        <div style="font-size: 11px; color: #a1a1aa; margin-top: 2px;">${escapeHtml(login.username || 'No username')}</div>
      `;

      itemBtn.addEventListener('mouseenter', () => {
        itemBtn.style.background = '#27272a';
      });
      itemBtn.addEventListener('mouseleave', () => {
        itemBtn.style.background = 'transparent';
      });

      itemBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        fillCredentials(login, passwordInput);
        dropdown.remove();
      });

      dropdown.appendChild(itemBtn);
    });

    // Close when clicking outside
    const closeListener = (e) => {
      if (!dropdown.contains(e.target)) {
        dropdown.remove();
        document.removeEventListener('click', closeListener);
      }
    };
    setTimeout(() => {
      document.addEventListener('click', closeListener);
    }, 10);

    container.appendChild(dropdown);
  }

  // Safely populate username and password inputs and trigger change events
  function fillCredentials(login, passwordInput) {
    // Fill password
    passwordInput.value = login.password;
    passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
    passwordInput.dispatchEvent(new Event('change', { bubbles: true }));

    // Find preceding username/email input in the same form or container
    const form = passwordInput.closest('form') || document;
    const usernameInput = form.querySelector(
      'input[type="text"], input[type="email"], input[autocomplete*="username"], input[name*="user"], input[name*="login"], input[name*="email"]'
    );

    if (usernameInput && login.username) {
      usernameInput.value = login.username;
      usernameInput.dispatchEvent(new Event('input', { bubbles: true }));
      usernameInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  function escapeHtml(str) {
    return str.replace(/[&<>'"]/g, (tag) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  // Initial check on load
  checkAndAttachAutofill();

  // Re-check periodically for dynamic SPAs
  setInterval(checkAndAttachAutofill, 2500);
})();
