/**
 * Databytes Keyhouse — Chrome Extension Manifest V3 Background Service Worker
 *
 * Handles encrypted sync, in-memory credential storage while unlocked,
 * origin matching, and 15-minute auto-locking.
 */

// In-memory runtime state (never written to disk in plaintext)
let sessionState = {
  isUnlocked: false,
  items: [],
  userEmail: null,
  vaultVersion: 0,
  serverUrl: 'https://ais-dev-co4gob4lg4iddfeaoxhusv-474810200924.europe-west2.run.app',
  lockTimerId: null,
  inactivityLimitMinutes: 15
};

// Reset auto-lock timer
function resetAutoLock() {
  if (sessionState.lockTimerId) {
    clearTimeout(sessionState.lockTimerId);
  }
  sessionState.lockTimerId = setTimeout(() => {
    lockVault();
  }, sessionState.inactivityLimitMinutes * 60 * 1000);
}

// Lock vault and purge all decrypted items from memory
function lockVault() {
  if (sessionState.lockTimerId) {
    clearTimeout(sessionState.lockTimerId);
    sessionState.lockTimerId = null;
  }
  sessionState.isUnlocked = false;
  sessionState.items = [];
  console.log('[Databytes Keyhouse] Vault locked due to inactivity or user command');
  // Broadcast lock state to popup or tabs
  chrome.runtime.sendMessage({ type: 'VAULT_LOCKED' }).catch(() => {});
}

// Extract canonical registrable domain or hostname for origin checks
function extractHostname(urlStr) {
  try {
    const url = new URL(urlStr);
    return url.hostname.toLowerCase();
  } catch (e) {
    return '';
  }
}

// Strict origin matching: does itemUrl match pageUrl?
function matchesOrigin(itemUrl, pageUrl) {
  if (!itemUrl || !pageUrl) return false;
  try {
    const itemHost = extractHostname(itemUrl);
    const pageHost = extractHostname(pageUrl);
    if (!itemHost || !pageHost) return false;

    // Exact hostname match
    if (itemHost === pageHost) return true;

    // Subdomain matching (e.g. login.example.com matches example.com, but never example.com.attacker.com)
    if (pageHost.endsWith('.' + itemHost)) return true;
    if (itemHost.endsWith('.' + pageHost)) return true;

    return false;
  } catch (e) {
    return false;
  }
}

// Web Crypto base64 decoder
function fromBase64(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

// Derive AES-256-GCM key from passphrase
async function deriveMasterKey(passphrase, saltBytes) {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: saltBytes,
      iterations: 100000,
      hash: 'SHA-256'
    },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt', 'encrypt']
  );
}

// Decrypt vault envelope
async function decryptEnvelope(envelope, passphrase) {
  const salt = fromBase64(envelope.kdf.salt);
  const iv = fromBase64(envelope.encryption.iv);
  const ciphertext = fromBase64(envelope.ciphertext);

  const key = await deriveMasterKey(passphrase, salt);

  const decryptedBuffer = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    ciphertext
  );

  const dec = new TextDecoder();
  return JSON.parse(dec.decode(decryptedBuffer));
}

// Message Dispatcher
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  resetAutoLock();

  switch (message.type) {
    case 'GET_STATUS': {
      sendResponse({
        isUnlocked: sessionState.isUnlocked,
        userEmail: sessionState.userEmail,
        vaultVersion: sessionState.vaultVersion,
        itemCount: sessionState.items.length,
        inactivityLimitMinutes: sessionState.inactivityLimitMinutes
      });
      break;
    }

    case 'UNLOCK_WITH_PASSPHRASE': {
      const { passphrase, envelope, userEmail } = message;
      decryptEnvelope(envelope, passphrase)
        .then((items) => {
          sessionState.isUnlocked = true;
          sessionState.items = items;
          sessionState.userEmail = userEmail || 'user@example.com';
          sessionState.vaultVersion = envelope.vaultVersion || 1;
          resetAutoLock();
          sendResponse({ success: true, count: items.length });
        })
        .catch((err) => {
          sendResponse({ success: false, error: 'Incorrect vault unlock secret or invalid envelope' });
        });
      return true; // Keep message channel open for async response
    }

    case 'LOCK_VAULT': {
      lockVault();
      sendResponse({ success: true });
      break;
    }

    case 'GET_MATCHING_LOGINS': {
      if (!sessionState.isUnlocked) {
        sendResponse({ isUnlocked: false, logins: [] });
        return;
      }

      const activeUrl = message.url || (sender.tab && sender.tab.url);
      if (!activeUrl) {
        sendResponse({ isUnlocked: true, logins: [] });
        return;
      }

      // Filter only login items that match the current website origin
      const matches = sessionState.items
        .filter((item) => item.type === 'login' && item.fields && item.fields.url)
        .filter((item) => matchesOrigin(item.fields.url, activeUrl))
        .map((item) => ({
          id: item.id,
          name: item.name,
          username: item.fields.username || '',
          password: item.fields.password || '',
          url: item.fields.url || ''
        }));

      sendResponse({ isUnlocked: true, logins: matches });
      break;
    }

    case 'SYNC_LOCAL_VAULT': {
      // Sync unlocked items passed directly from the web client
      if (message.items && Array.isArray(message.items)) {
        sessionState.items = message.items;
        sessionState.isUnlocked = true;
        sessionState.userEmail = message.userEmail || sessionState.userEmail;
        sessionState.vaultVersion = message.vaultVersion || sessionState.vaultVersion;
        resetAutoLock();
        sendResponse({ success: true, count: message.items.length });
      } else {
        sendResponse({ success: false, error: 'No items provided' });
      }
      break;
    }

    default:
      sendResponse({ error: 'Unknown message type' });
  }
});

console.log('[Databytes Keyhouse] Background service worker initialized');
